<?php $config = [
    'db_name' => 'if0_39821829_spital_php',
    'db_user' => 'if0_39821829',
    'db_password' => 'GjszOUxt9W3Zfp',
    'db_host' => 'sql108.infinityfree.com',
    'RECAPTCHA_SITE_KEY' => '6LcGqrArAAAAALQjbdusa6zE-ltBQDLPRDQq8xI4',
    'RECAPTCHA_SECRET_KEY' => '6LcGqrArAAAAAMHfrfuGhKsx2_f9EBNVgRiHaKDp',
]; ?>

<?php $config = [
    'db_name' => 'phpspital',
    'db_user' => 'robi',
    'db_password' => 'robi',
    'db_host' => 'localhost',
    'RECAPTCHA_SITE_KEY' => '6LcGqrArAAAAALQjbdusa6zE-ltBQDLPRDQq8xI4',
    'RECAPTCHA_SECRET_KEY' => '6LcGqrArAAAAAMHfrfuGhKsx2_f9EBNVgRiHaKDp',
]; ?>

<?php
require_once 'app/models/User.php';

class UserController
{
    public static function index()
    {
        $users = User::getAllUsers();
        require_once 'app/views/users/index.php';
    }
    public static function show()
    {
        $user_id = $_GET['id'];
        $user = User::getUser($user_id);

        if ($user) {
            require_once 'app/views/users/index.php';
        } else {
            $_SESSION['error'] = 'User not found';
            require_once 'app/views/404.php';
        }
    }
    public static function edit()
    {
        // GET este setat cand userul apasa pe butonul edit
        // POST este setat cand userul apasa pe butonul submit
    }
}

?>
